/**
 * @name Dhruv Patel
 * @version 0.0.1
 * @description Example Description
 * @author Example
 *  
 */



 module.exports = class Example{
     
    load() { }
    start() {

//code here

//stop coding
}
stop(){

}
}