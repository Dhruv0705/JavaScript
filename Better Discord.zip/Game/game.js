<canvas id= 'canvas' width='640' height = '480'></canvas>
var canvas = document.getElementById("canvas");
var cfx = canvas.getContext("2d");
ctx.fillStyle = "#f00";
ctx.fillRect(270,190,100,100);


